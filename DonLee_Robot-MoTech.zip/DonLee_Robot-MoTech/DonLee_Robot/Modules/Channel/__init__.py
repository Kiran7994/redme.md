DEPLOY = "💡 DEPLOY NOW 💡"
HEROKU = "https://youtu.be/lI71HsWzTKE"
