import os
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
class Mo_Tech_YT(object):
    MO_TECH_YT_01 = InlineKeyboardMarkup
    MO_TECH_YT_02 = InlineKeyboardButton
    MO_TECH_YT_03 = os.environ.get("DB_URI")
    MO_TECH_YT_04 = os.environ.get("DB_NAME", "mOtech")
    MO_TECH_YT_05 = os.environ.get("EXPELL").split()
    MO_TECH_YT_06 = os.environ.get("KITTUMO")
    MO_TECH_YT_07 = bool(os.environ.get("SIZE_BUTTON"))
    MO_TECH_YT_08 = os.environ.get("IN_EXPELL").split()
    MO_TECH_YT_09 = set(int(x) for x in os.environ.get("OWNER_ID", "").split())
    MO_TECH_YT_10 = int(os.environ.get("APP_ID"))
    MO_TECH_YT_11 = os.environ.get("API_HASH")
    MO_TECH_YT_12 = os.environ.get("BOT_TOKEN")
    MO_TECH_YT_13 = os.environ.get("PHOTTO", "https://telegra.ph/file/7d04d3370126136c9c7a9.jpg")
    MO_TECH_YT_14 = os.environ.get("FSUB_TEXT", "Join My Update Channel")
    MO_TECH_YT_15 = os.environ.get("FORCES_SUB", "Mo_Tech_YT")
    MO_TECH_YT_16 = os.environ.get("USER_SESSION")
