# (c) @AlbertEinsteinTG
# (c) @Muhammed_RK, @MRK_YT, @Mo_Tech_Group, @MT_Botz
# Copyright permission under MIT License
# All rights reserved by PR0FESS0R-99
# License -> https://github.com/PR0FESS0R-99/DonLee_Robot/blob/main/LICENSE

from .donlee_robot import DonLee_Robot

app = DonLee_Robot()
app.run()
