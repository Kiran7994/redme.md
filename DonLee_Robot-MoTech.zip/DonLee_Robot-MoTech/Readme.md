# [DONLEE_ROBOT](https://telegram.dog/Donlee_Robot)

<p align="center">
  <a href="https://github.com/PR0FESS0R-99/DonLee_Robot/stargazers">
    <img src="https://img.shields.io/github/stars/PR0FESS0R-99/DonLee_Robot?style=social">

  </a>
  
  <a href="https://github.com/PR0FESS0R-99/DonLee_Robot/fork">
    <img src="https://img.shields.io/github/forks/PR0FESS0R-99/DonLee_Robot?label=Fork&style=social">

  </a>  
</p>

--------

This Is Just An Simple Advance Auto Filter Bot Complete Rewritten Version Of [Adv-Auto-Filter-Bot-v1](https://github.com/CrazyBotsz/Adv-Auto-Filter-Bot)

Just Sent Any Text As Query It Will Search For All Connected Chat's Files In Its MongoDB And Reply You With The Message Link As A Button

------

#### FEATURE

* IMDB Poster Available
* Spelling Mode
* Main Text Mode (Kitto, Undo, Ille, Therumo)
* Button Mode
* Movie Text Mode (movie, Movie)

--------
##### Available DonLee Bots

<details><summary>Auto Filter Orginal</summary>
<p>
<br>

### Notice
* This [Deploy button](https://heroku.com/deploy?template=https://github.com/PR0FESS0R-99/DonLee_Robot/tree/main) is the original
* Click [Deploy Video](https://youtu.be/uAHl5jvnrhk) to watch the video

#### Deploy Video
<a href="https://youtu.be/uAHl5jvnrhk"><img src="https://img.shields.io/badge/Deploy%20Video-blue.svg?logo=Youtube"></a>
<a href="https://youtu.be/uAHl5jvnrhk"><img src="https://img.shields.io/youtube/views/uAHl5jvnrhk?style=social">

#### Deploy To Heroku
<a href="https://heroku.com/deploy?template=https://github.com/PR0FESS0R-99/DonLee_Robot/tree/main"><img src="https://i.ibb.co/tsq26Pz/PR0-FESS0-R-99.gif" alt="PR0FESS0R-99" border="0" height="125" width="200" align="center" /></a>
</p>
</details>

<details><summary>Auto Filter 3 Editing Repo</summary>
<p>
<br>

### Notice
* This [Deploy button](https://heroku.com/deploy?template=https://github.com/PR0FESS0R-99/DonLee_Robot/tree/MoTech) is the original
* Click [Deploy Video](https://youtu.be/lI71HsWzTKE) to watch the video

#### Deploy Video
<a href="https://youtu.be/lI71HsWzTKE"><img src="https://img.shields.io/badge/Deploy%20Video-blue.svg?logo=Youtube"></a>
<a href="https://youtu.be/lI71HsWzTKE"><img src="https://img.shields.io/youtube/views/lI71HsWzTKE?style=social">

#### Deploy To Heroku
<a href="https://heroku.com/deploy?template=https://github.com/PR0FESS0R-99/DonLee_Robot/tree/MoTech"><img src="https://i.ibb.co/tsq26Pz/PR0-FESS0-R-99.gif" alt="PR0FESS0R-99" border="0" height="125" width="200" align="center" /></a>

</a>
</p>
</details>

----

##### Usage

**How To Use Me!?**

* Add me to any group and make me admin<br>
* Add me to your channel as admin with full previlages

**Bot Commands (Works Only In Groups) :**


  * -> `/add chat_id`<br>
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
OR
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- To establish a connection of group with a channel (Bot should be admin with full previlages in both group and channel)<br>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;`/add @Username`


  * -> `/del chat_id`<br>
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
OR 
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- To delete a group's coneection with a channel (Use disable option from settigns pannel for disconnecting temporarily instead of deleteing)<br>
    &nbsp;&nbsp;&nbsp;&nbsp; `/del @Username`


  * `/delall`&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - To delete all connections of a group and deletes all its file from DB
  
  * `/settings`&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -  To disaply a Settings Pannel Instance which can be used to tweek bot's settings accordingly

    * Channel - Button will show you all the connected chats with the group along with there index buttons correspnding to there order for furthur controls...

    * Filter Types - Button will show you the 3 filter types available in bot... Pressing each buttons will either enable or disable them and this will take into action as soon as you use them...without the need of a restart....

    * Configure - Button will help you to change no. of pages/ buttons per page/ total result without acutally editing the repo... Also it provide option to Enable/Disable  showing Invite Link in each results

    * Status - Button will show the stats of your current group

------------------
##### Main Pre Requisites

* Your Bot Token From [@BotFather](https://youtu.be/cB4UduCcNWs)__

* Your APP ID And API Harsh From [Telegram](https://youtu.be/5eEsvLAKVc0) or [@MT_MytelegramOrg_Bit](https://youtu.be/5eEsvLAKVc0)

* Your User Session String Obtained From [Telegram Bot](https://youtu.be/WUN_12-dYOM)

* Mongo DB URL Obtained From [Mongo DB](https://youtu.be/gBLTsH-IXr0)

----
##### Support   
Join Our [Telegram Group](https://www.telegram.dog/Mo_Tech_Group) For Support/Assistance And Our [Channel](https://www.telegram.dog/Mo_Tech_YT) For Updates.   
   
Report Bugs, Give Feature Requests There..   
Do Fork And Star The Repository If You Liked It.
----
##### Disclaimer
[![GNU Affero General Public License v3.0](https://www.gnu.org/graphics/agplv3-155x51.png)](https://www.gnu.org/licenses/agpl-3.0.en.html#header)    
Licensed under [GNU AGPL v3.0.](https://github.com/PR0FESS0R-99/DonLee_Robot/blob/main/LICENSE)
Selling The Codes To Other People For Money Is *Strictly Prohibited*.
----
## Credits

 - Thanks To Dan For His Awsome [Libary](https://github.com/pyrogram/pyrogram)
 - Thanks To SpEcHiDe For His Awesome [DeleteMessagesRoBot](https://github.com/SpEcHiDe/DeleteMessagesRoBot)
 - [Thanks To AlbertEinsteinTG 👀](https://github.com/AlbertEinsteinTG)
 - [PR0FESS0R-99](https://github.com/PR0FESS0R-99), [Mo_Tech_Group](https://telegram.dog/Mo_Tech_Group), [MT_Botz](https://telegram.dog/MT_Botz)
